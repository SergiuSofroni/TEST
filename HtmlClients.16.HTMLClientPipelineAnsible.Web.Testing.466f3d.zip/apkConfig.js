var apkConfig = {
    isApk: false,
    version: '1.2.0'
};